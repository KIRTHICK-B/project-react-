import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Modal from 'react-modal';
import { UserContext } from '../App';
import './Dashboard.css'; 

function Dashboard() {
  const { user, setUser } = useContext(UserContext);
  const [classrooms, setClassrooms] = useState([]);
  const [currentClassroom, setCurrentClassroom] = useState(null);
  const [students, setStudents] = useState([]);
  const [newClassName, setNewClassName] = useState('');
  const [newStudent, setNewStudent] = useState({
    name: '',
    rollNumber: '',
    fatherName: '',
    address: '',
    dob: '',
    aadhaarNumber: '',
    emisNumber: '',
  });
  const [editStudentIndex, setEditStudentIndex] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const navigate = useNavigate();

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleLogout = () => {
    setUser(null);
    navigate('/');
  };

  const handleCreateClassroom = () => {
    const newClassName = prompt('Enter the name of the classroom:');
  
    if (newClassName === null) {
      // User clicked Cancel
      return;
    }
  
    if (newClassName.trim() === '') {
      alert('Please enter a valid classroom name.');
      return;
    }
  
    const newClassroom = {
      id: classrooms.length + 1,
      name: newClassName,
      students: [],
    };
    setClassrooms((prevClassrooms) => [...prevClassrooms, newClassroom]);
  };

  const handleSelectClassroom = (classroom) => {
    setCurrentClassroom(classroom);
    setStudents(classroom.students);
  };

  const handleAddOrUpdateStudent = () => {
    if (
      !newStudent.rollNumber ||
      !newStudent.name ||
      !newStudent.dob ||
      !newStudent.fatherName ||
      !newStudent.address ||
      !newStudent.aadhaarNumber ||
      !newStudent.emisNumber
    ) {
      alert('Please provide all required information.');
      return;
    }
  
    if (editStudentIndex !== null) {
      // Update existing student
      const updatedStudents = [...students];
      updatedStudents[editStudentIndex] = newStudent;
      setStudents(updatedStudents);
    } else {
      // Add new student
      setStudents((prevStudents) => [...prevStudents, newStudent]);
    }
  
    // Clear form fields
    setNewStudent({
      rollNumber: '',
      name: '',
      dob: '',
      fatherName: '',
      address: '',
      aadhaarNumber: '',
      emisNumber: '',
    });
  
    // Reset edit state
    setEditStudentIndex(null);
  };
  
  const handleEditStudent = (index) => {
    setNewStudent(students[index]);
    setEditStudentIndex(index);
    handleOpenModal();
  };

  const handleDeleteStudent = (index) => {
    const updatedStudents = [...students];
    updatedStudents.splice(index, 1);
    setStudents(updatedStudents);
  };

  return (
    <div className="container">
      <h2>Welcome, {user && user.username}!</h2>
        <button onClick={handleLogout} className="logout-btn">
          Logout
        </button>
      <div className="header">
        <button onClick={handleCreateClassroom} className="create-classroom-btn">
          Create Classroom
        </button>
        <div className="dropdown">
          <button className="dropbtn">Classrooms</button>
          <div className="dropdown-content">
            {classrooms.map((classroom) => (
              <button
                key={classroom.id}
                onClick={() => handleSelectClassroom(classroom)}
              >
                {classroom.name}
              </button>
            ))}
          </div>
        </div>
      </div>
      {currentClassroom ? (
        <div>
          <h3>Classroom: {currentClassroom.name}</h3>
          <button onClick={handleOpenModal}>Add Student</button>
          <ul>
            {students.map((student, index) => (
              <li style={{fontSize:"large"}}  key={index}>
                {student.rollNumber} -{' '}
                {student.name} -{' '}
                {student.dob} -{' '}
                {student.fatherName} -{' '}
                {student.address} -{' '}
                {student.aadhaarNumber} -{' '}
                {student.emisNumber} -{' '}
                <button onClick={() => handleEditStudent(index)}>Edit</button>{' '}
                <button onClick={() => handleDeleteStudent(index)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p>Select a classroom to view and manage students.</p>
      )}

      <Modal
        isOpen={isModalOpen}
        onRequestClose={handleCloseModal}
        contentLabel="Create Classroom Modal"
        className="modal"
      >
        <h3>{editStudentIndex !== null ? 'Edit Student' : 'Add Student'}</h3>
        <label>
            Roll Number:<br></br> 
          <input className='i'
            type="text"
            value={newStudent.rollNumber}
            onChange={(e) =>
              setNewStudent({ ...newStudent, rollNumber: e.target.value })
            }
          />
        </label>
        <br></br>
        <label>
          Name :<br></br>
          <input className='i'
            type="text"
            value={newStudent.name}
            onChange={(e) =>
              setNewStudent({ ...newStudent, name: e.target.value })
            }
          />
        </label><br></br>
        <label>
          DOB : <br></br>
          <input className='i'
            type="text"
            value={newStudent.dob}
            onChange={(e) =>
              setNewStudent({ ...newStudent, dob: e.target.value })
            }
          />
        </label><br></br>
        <label>
          Father Name : <br></br>
          <input className='i'
            type="text"
            value={newStudent.fatherName}
            onChange={(e) =>
              setNewStudent({ ...newStudent, fatherName: e.target.value })
            }
          />
        </label><br></br>
        <label>
          Address : <br></br>
          <input className='i'
            type="text"
            value={newStudent.address}
            onChange={(e) =>
              setNewStudent({ ...newStudent, address: e.target.value })
            }
          />
        </label><br></br>
        <label>
          Aadhaar Number : <br></br>
          <input className='i'
            type="text"
            value={newStudent.aadhaarNumber}
            onChange={(e) =>
              setNewStudent({ ...newStudent, aadhaarNumber: e.target.value })
            }
          />
        </label><br></br>
        <label>
          EMIS Number : <br></br>
          <input className='i'
            type="text"
            value={newStudent.emisNumber}
            onChange={(e) =>
              setNewStudent({ ...newStudent, emisNumber: e.target.value })
            }
          />
        </label><br></br>
       
        <button onClick={handleAddOrUpdateStudent}>
          {editStudentIndex !== null ? 'Update Student' : 'Add Student'}
        </button>
        <button onClick={handleCloseModal}>Cancel</button>
      </Modal>
    </div>
  );
}

export default Dashboard;

