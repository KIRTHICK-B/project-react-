import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserContext } from '../App';
import './SignUp.css';

function SignUp() {
  const { setUser } = useContext(UserContext);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleInputChange = (e) => {
    
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSignup = () => {
  if(formData.confirmPassword===""||formData.email===""||formData.password===""||formData.username==="")
    {
      alert('fill out the data');
    }else{
    setUser({ username: formData.username }); // You can replace this with actual authentication logic
    navigate('/dashboard');}
  };

  return (
    <div className='signup'>
      <form className='form'>
          <h1>Sign Up</h1>
        
          <input placeholder='USERNAME'className='i' type="text" name="username" value={formData.username} onChange={handleInputChange} required /><br></br>
       
          <input placeholder='EMAIL'className='i'type="email" name="email" value={formData.email} onChange={handleInputChange} required /><br></br>
        
          <input placeholder='CREATE PASSWORD'className='i'type="password" name="password" value={formData.password} onChange={handleInputChange} required /><br></br>
        
          <input placeholder='CONFIRM PASSWORD'className='i'type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleInputChange} required /><br></br>
        
        <button className='b'type="button" onClick={handleSignup}>Sign Up</button>
      </form>
      <p>Already have an account? <Link to="/login">Login here</Link>.</p>
    </div>
  );
}

export default SignUp;