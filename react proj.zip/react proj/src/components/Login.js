import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserContext } from '../App';
import './Login.css';

function Login() {
  const { setUser } = useContext(UserContext);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handlelogin = () => {
    if( formData.username === "" || formData.password === "")
    {
      alert('fill out the data');
    }
    else{
    setUser({ username: formData.username }); // You can replace this with actual authentication logic
    navigate('/dashboard');}
  };

  return (
    <div className='loginbox'>
      <form className='form'>
          <h1>LOGIN</h1>
        
          <input placeholder='USERNAME'className='i' type="text" name="username" value={formData.username} onChange={handleInputChange} required /><br></br>
        
          <input placeholder='PASSWORD'className='i'type="password" name="password" value={formData.password} onChange={handleInputChange} required /><br></br>
        
          
        
        <button className='b'type="button" onClick={handlelogin}>Login</button>
      </form>
      <p>Don't have an account? <Link to="/signup">Sign up here</Link>.</p>
    </div>
  );
}

export default Login;