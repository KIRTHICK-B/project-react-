import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

function Home() {
  return (
    <div className='home'>
      <br></br>
        <text style={{fontSize:"40px"}}><b>Welcome to the Student Database Management System<br></br>&emsp;
        Please <Link to="/login">login</Link> or <Link to="/signup">sign up</Link> to access the classrooms</b></text>
    </div>
  );
}

export default Home;